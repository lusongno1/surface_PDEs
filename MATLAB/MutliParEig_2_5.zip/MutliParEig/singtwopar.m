function [lambda,mu] = singtwopar(A1,B1,C1,A2,B2,C2)

%SINGTWOPAR Solve a singular two-parameter eigenvalue problem using
% rank-completing perturbations
% 
% [lambda,mu] = SINGTWOPAR(A1,B1,C1,A2,B2,C2) returns
% eigenvalues of a (singular) two-parameter eigenvalue problem
%
% A1 x = lambda B1 x + mu C1 x 
% A2 y = lambda B2 y + mu C2 y
%
% Input:
%   - A1, B1, C1, A2, B2, C2: matrices
%
% Output: 
%   - lambda, mu: eigenvalue parts (eigenvalues are (lambda(j),mu(j))

% Reference: Algorithm 2 in 
% M.E. Hochstenbach, C. Mehl, B. Plestenjak: Solving singular generalized 
% eigenvalue problems by a rank-completing perturbation, arXiv:1805:07657

% MultiParEig toolbox
% B. Plestenjak, University of Ljubljana
% FreeBSD License, see LICENSE.txt

% Bor Plestenjak
% 23.05.2018

[Delta0,Delta1,~] = twopar_delta(A1,B1,C1,A2,B2,C2);

% We solve a singular two-parameter eigenvalue problem by first applying
% singgep to the pencil (Delta1,Delta0) and then by inserting computed
% lambda's in the pencil of the first and the second equation and comparing 
% the computed mu's. We assume that all eigenvalues are simple, i.e. to each
% lambda there corresponds exactly one mu.

lambda = singgep(Delta1,Delta0,0);

n = length(lambda);

for k = 1:n
    M1 = A1 - lambda(k)*B1;
    M2 = A2 - lambda(k)*B2;
    mu1 = singgep(M1,C1);
    mu2 = singgep(M2,C2);
    m1 = length(mu1);
    m2 = length(mu2);
    DD = abs(kron(mu1,ones(1,m2))-kron(ones(m1,1),mu2.'));
    [colmin,pos1] = min(DD);
    [~,pos2] = min(colmin);
    j = pos2;
    i = pos1(j);
    mu(k,1) = (mu1(i) + mu2(j))/2;
end

